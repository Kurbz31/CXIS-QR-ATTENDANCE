<?php

$conn = new mysqli("localhost:3306", "isnmcoso_wp_rzn22", "i&5w_DZ$26Ut4DR$", "isnmcoso_wp_qnuid");
if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}
?>